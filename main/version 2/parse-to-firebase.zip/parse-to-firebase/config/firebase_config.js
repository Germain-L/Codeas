var firebaseConfig = {
    apiKey: "DUMMY API KEY",
    authDomain: "DUMMY AUTH DOMAIN",
    databaseURL: "DUMMY DATABASE URL",
    projectId: "DUMMY PROJECT ID",
    storageBucket: "DUMMY STORAGE BUCKET",
    messagingSenderId: "DUMMY SENDER ID",
    appId: "DUMMY APP ID"
  };
